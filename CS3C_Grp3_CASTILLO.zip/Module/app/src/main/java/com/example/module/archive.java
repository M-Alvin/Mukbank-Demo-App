package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class archive extends AppCompatActivity {
    String numbers;
    private RecyclerView archiveRvs;
    private FirebaseAuth firebaseAuth;
    private ArrayList<modelArchive> AppointmentsLists;
    private adapterArchive adapterAppointments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_archive);

        archiveRvs=findViewById(R.id.archiveRv);
        Intent intent = getIntent();
        numbers = intent.getStringExtra("numbers");
        loadAppointments();
    }

    private void loadAppointments() {

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String  uid = "" + ds.child("Phone").getValue();


                            AppointmentsLists= new ArrayList<>();
                            DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Archive");
                            ref.orderByChild("Phone").equalTo(""+numbers)
                                    .addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            for (DataSnapshot ds : snapshot.getChildren()) {
                                                modelArchive modelAppoint = ds.getValue(modelArchive.class);
                                                AppointmentsLists.add(modelAppoint);

                                            }
                                            //setup adapter
                                            adapterAppointments = new adapterArchive(archive.this, AppointmentsLists);
                                            //set adapter
                                            archiveRvs.setAdapter(adapterAppointments);
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });

                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}