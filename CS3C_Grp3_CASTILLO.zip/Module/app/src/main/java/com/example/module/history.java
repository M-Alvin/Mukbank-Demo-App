package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collection;

public class history extends AppCompatActivity {
    private RecyclerView transacRv;
    private FirebaseAuth firebaseAuth;
    private ArrayList<modelHistory> AppointmentsLists;
    private adapterHistory adapterAppointments;
    ImageView backs , filters;
    String numbers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        firebaseAuth = firebaseAuth.getInstance();
        Intent intent = getIntent();
        numbers = intent.getStringExtra("number");

        backs=findViewById(R.id.back);
        filters=findViewById(R.id.filter);

        backs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(history.this, home.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });

        filters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(history.this, filtering.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });

        transacRv = findViewById(R.id.transRv);
        loadHistory();

    }

    private void loadHistory() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String  uid = "" + ds.child("Phone").getValue();


                            AppointmentsLists= new ArrayList<>();

                            DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Transaction");
                            ref.orderByChild("Phone").equalTo(""+numbers)
                                    .addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            for (DataSnapshot ds : snapshot.getChildren()) {

                                                modelHistory modelAppoint = ds.getValue(modelHistory.class);
                                                AppointmentsLists.add(modelAppoint);

                                            }
                                            //setup adapter
                                            adapterAppointments = new adapterHistory(history.this, AppointmentsLists);
                                            //set adapter
                                            transacRv.setAdapter(adapterAppointments);

                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });

                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}