package com.example.module;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Investment extends AppCompatActivity {
    TextView houses1,houses2,houses3,schools1,schools2,schools3,retires1,retires2,retires3,lifes1,lifes2,companys1,companys2;
    ImageView backs;
    String numbers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_investment);

        Intent intent = getIntent();
        numbers = intent.getStringExtra("number");
        backs=findViewById(R.id.back);

        houses1=findViewById(R.id.house1);
        houses2=findViewById(R.id.house2);
        houses3=findViewById(R.id.house3);
        schools1=findViewById(R.id.school1);
        schools2=findViewById(R.id.school2);
        schools3=findViewById(R.id.school3);
        retires1=findViewById(R.id.retire1);
        retires2=findViewById(R.id.retire2);
        retires3=findViewById(R.id.retire3);
        lifes1=findViewById(R.id.life1);
        lifes2=findViewById(R.id.life2);
        companys1=findViewById(R.id.company1);
        companys2=findViewById(R.id.company1);


        houses1.setMovementMethod(LinkMovementMethod.getInstance());
        houses2.setMovementMethod(LinkMovementMethod.getInstance());
        houses3.setMovementMethod(LinkMovementMethod.getInstance());
        schools1.setMovementMethod(LinkMovementMethod.getInstance());
        schools2.setMovementMethod(LinkMovementMethod.getInstance());
        schools3.setMovementMethod(LinkMovementMethod.getInstance());
        retires1.setMovementMethod(LinkMovementMethod.getInstance());
        retires2.setMovementMethod(LinkMovementMethod.getInstance());
        retires3.setMovementMethod(LinkMovementMethod.getInstance());
        lifes1.setMovementMethod(LinkMovementMethod.getInstance());
        lifes2.setMovementMethod(LinkMovementMethod.getInstance());
        companys1.setMovementMethod(LinkMovementMethod.getInstance());
        companys2.setMovementMethod(LinkMovementMethod.getInstance());


        backs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Investment.this, home.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });

    }
}