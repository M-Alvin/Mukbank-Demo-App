package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class Savings extends AppCompatActivity {

    private RecyclerView savingRv;
    private FirebaseAuth firebaseAuth;
    private ArrayList<modelSavings> AppointmentsLists;
    private adapterSavings adapterAppointments;
    String formatedDate,formatedTime;
    ImageView backs;
    private ImageView adds;
    Dialog dialog;
    DrawerLayout drawerLayout;
    String numbers , bal;
    private EditText savings, amounts ;
    private Button saves,cancels;
    int bals;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savings);



        backs=findViewById(R.id.back);

        Intent intent = getIntent();
        firebaseAuth = firebaseAuth.getInstance();
        loadAppointments();
        numbers = intent.getStringExtra("number");
        savingRv = findViewById(R.id.savingsRv);
        adds = findViewById(R.id.add);
        loadAppointments();

        dialog = new Dialog(Savings.this);
        dialog.setContentView(R.layout.savings);

        dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.backgrounds));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(false);
        dialog.getWindow().getAttributes().windowAnimations = R.style.animation;

        savings = dialog.findViewById(R.id.saving);
        amounts = dialog.findViewById(R.id.amount);
        saves = dialog.findViewById(R.id.save);
        cancels = dialog.findViewById(R.id.cancel);

        cancels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        backs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Savings.this, home.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });



adds.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        dialog.show();
    }
});

saves.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        inputData();




    }
});


        DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {

                            bal = ""+ds.child("Account").getValue();

                        }
                         bals = Integer.parseInt(bal);



                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


    }

    private void loadAppointments() {

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String  uid = "" + ds.child("Phone").getValue();


                            AppointmentsLists= new ArrayList<>();
                            DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Savings");
                            ref.orderByChild("Phone").equalTo(""+numbers)
                                    .addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            for (DataSnapshot ds : snapshot.getChildren()) {
                                                modelSavings modelAppoint = ds.getValue(modelSavings.class);
                                                AppointmentsLists.add(modelAppoint);

                                            }
                                            //setup adapter
                                            adapterAppointments = new adapterSavings(Savings.this, AppointmentsLists);
                                            //set adapter
                                            savingRv.setAdapter(adapterAppointments);
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });

                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                        }



    String saving , amount ,tot ;
    private void inputData() {
        saving = savings.getText().toString().trim();
        amount = amounts.getText().toString().trim();

        int amount1 = Integer.parseInt(amount);

        int total=bals-amount1;

         tot = String.valueOf(total);




        addData();
    }

    private void addData() {
        final String timestamp = "" + System.currentTimeMillis();
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("Transaction", "Savings");
        hashMap.put("Savings", "" + saving);
        hashMap.put("Amount", "" + amount);
        hashMap.put("Balance", "" + tot);
        hashMap.put("Phone", "" + numbers);
        hashMap.put("timestamp", "" + timestamp);
        hashMap.put("uid", "" + firebaseAuth.getUid());

        //add now to database
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(""+numbers).child("Savings").child(timestamp).setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {

                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(Savings.this, "Saved", Toast.LENGTH_SHORT).show();

                        HashMap<String, Object> hashMap1 = new HashMap<>();
                        hashMap1.put("Account", "" + tot);

                        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
                        reference.child(""+numbers).updateChildren(hashMap1)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {

                                       ///start

                                        Calendar calendar = Calendar.getInstance();
                                        calendar.setTimeInMillis(Long.parseLong(timestamp));
                                        formatedDate = DateFormat.format("LLL/dd/yyyy",calendar).toString();
                                        formatedTime = DateFormat.format("hh:mm a",calendar).toString();



                                        HashMap<String, Object> hashMap1 = new HashMap<>();
                                        hashMap1.put("Transaction", "Savings");
                                        hashMap1.put("Time", "" + formatedTime);
                                        hashMap1.put("Date", "" + formatedDate);
                                        hashMap1.put("Send", "" + saving);
                                        hashMap1.put("Amount", "" + amount);
                                        hashMap1.put("Phone", "" + numbers);
                                        hashMap1.put("From", "" + numbers);
                                        hashMap1.put("timestamp", "" + timestamp);
                                        hashMap1.put("uid", "" + firebaseAuth.getUid());

                                        //add now to database
                                        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
                                        reference.child(""+numbers).child("Transaction").child(timestamp).setValue(hashMap1)
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {

                                                    @Override
                                                    public void onSuccess(Void aVoid) {

                                                        dialog.dismiss();


                                                    }
                                                    })
                                                            .addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Toast.makeText(Savings.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                                        }
                                                    });

                                       ///end


                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(Savings.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(Savings.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }




}