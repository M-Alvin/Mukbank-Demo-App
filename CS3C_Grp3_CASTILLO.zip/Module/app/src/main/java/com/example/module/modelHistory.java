package com.example.module;

public class modelHistory {
    private String Amount,From,Send,uid, timestamp ,Transaction,Date,Time;

    public modelHistory() {

    }

    public modelHistory(String amount, String from, String send, String uid, String timestamp, String transaction, String date, String time) {
        Amount = amount;
        From = from;
        Send = send;
        this.uid = uid;
        this.timestamp = timestamp;
        Transaction = transaction;
        Date = date;
        Time = time;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }

    public String getFrom() {
        return From;
    }

    public void setFrom(String from) {
        From = from;
    }

    public String getSend() {
        return Send;
    }

    public void setSend(String send) {
        Send = send;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getTransaction() {
        return Transaction;
    }

    public void setTransaction(String transaction) {
        Transaction = transaction;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }
}
