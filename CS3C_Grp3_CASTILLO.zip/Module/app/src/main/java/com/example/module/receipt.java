package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.core.widget.NestedScrollView;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.format.DateFormat;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class receipt extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    Display mDisplay;
    String path;
    String imagesUri;
    Bitmap bitmap;
    int totalHeight;
    int totalWidth;
    String numberc,number1c,amountc, times,formatedDate,formateTime;
    TextView send,phone, date ,timez ;
    Button doness;
    public static final int READ_PHONE = 110;
    String file_name = "Screenshot";
    File mypath;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        send = findViewById(R.id.sends);
        date = findViewById(R.id.dates);
        phone = findViewById(R.id.phones);
        doness = findViewById(R.id.doness);

        firebaseAuth = FirebaseAuth.getInstance();
        Intent intent = getIntent();
        numberc = intent.getStringExtra("from");
        number1c = intent.getStringExtra("send");
        amountc = intent.getStringExtra("amount");
        times = intent.getStringExtra("timestamp");

        timez = findViewById(R.id.times);
        send.setText(convertText(amountc+".00"));
        phone.setText(number1c);
        ////start ------------------------
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Long.parseLong(times));
        formatedDate = DateFormat.format("LLL/dd/yyyy",calendar).toString();
        formateTime = DateFormat.format("hh:mm a",calendar).toString();


        date.setText(formatedDate);

        timez.setText(formateTime);


        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE},
                PackageManager.PERMISSION_GRANTED);

doness.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {


        wew();




    }
});

    }

    private String convertText(String text){
        StringBuilder stringBuilder = new StringBuilder(text);
        for (int i = stringBuilder.length() - 6;i>0;i-=3){
            stringBuilder.insert(i,",");


        }
        return stringBuilder.toString();
    }




    public void screenshot (View view){
        doness.setVisibility(View.GONE);
        view.setVisibility(View.GONE);




        View view1 = view.getRootView();

        Bitmap bitmap = Bitmap.createBitmap(view1.getWidth(),view1.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        view1.draw(canvas);


        File fileScreenshot = new File(this.getExternalFilesDir(Environment.DIRECTORY_PICTURES),Calendar.getInstance().getTime().toString()+".jpg");




        try{
            FileOutputStream fileOutputStream = new FileOutputStream(fileScreenshot);
                bitmap.compress(Bitmap.CompressFormat.JPEG,100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();


        }
        catch (Exception e){

        }



        done();

    }



    private void done() {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("Transaction", "Send Money");
        hashMap.put("Time", "" + formateTime);
        hashMap.put("Date", "" + formatedDate);
        hashMap.put("Send", "" + number1c);
        hashMap.put("From", "" + numberc);
        hashMap.put("Phone", "" + numberc);
        hashMap.put("Amount", "" + amountc);
        hashMap.put("timestamp", "" + times);
        hashMap.put("uid", "" + firebaseAuth.getUid());

        //add now to database
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(""+numberc).child("Transaction").child(times).setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {

                    @Override
                    public void onSuccess(Void aVoid) {

                        doness.setVisibility(View.VISIBLE);
                        Toast.makeText(receipt.this, "Saved Receipt", Toast.LENGTH_SHORT).show();



                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        ;    Toast.makeText(receipt.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        /////end

    }

   private void wew(){

        ///startt
        HashMap<String, Object> hashMap1 = new HashMap<>();
        hashMap1.put("Transaction", "Received Money");
        hashMap1.put("Time", "" + formateTime);
        hashMap1.put("Date", "" + formatedDate);
        hashMap1.put("Send", "" + number1c);
        hashMap1.put("From", "" + numberc);
        hashMap1.put("Phone", "" + number1c);
        hashMap1.put("Amount", "" + amountc);
        hashMap1.put("timestamp", "" + times);
        hashMap1.put("uid", "" + firebaseAuth.getUid());

        //add now to database
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child("" + number1c).child("Transaction").child(times).setValue(hashMap1)
                .addOnSuccessListener(new OnSuccessListener<Void>() {

                    @Override
                    public void onSuccess(Void aVoid) {

                        Intent intent = new Intent(receipt.this, home.class);
                        intent.putExtra("number", numberc);
                        startActivity(intent);

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(receipt.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


    }



}






