package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class home extends AppCompatActivity {


    ImageView saving,payments,invest,accounts,historys;
    TextView Balance,phones;
    String numbers;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        phones=findViewById(R.id.phone);

        saving = findViewById(R.id.savings);
        payments = findViewById(R.id.payment);
        historys = findViewById(R.id.history);

        Intent intent = getIntent();
        numbers = intent.getStringExtra("number");


        invest = findViewById(R.id.investment);
        accounts = findViewById(R.id.account);
        phones.setText(numbers);

        checkUser();

        Balance = findViewById(R.id.balance);

        accounts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String numbers=phones.getText().toString();


                Intent intent = new Intent(home.this,Account.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });

        historys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String numbers=phones.getText().toString();


                Intent intent = new Intent(home.this,history.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });

        saving.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          String numbers=phones.getText().toString();


                                          Intent intent = new Intent(home.this, Savings.class);
                                          intent.putExtra("number",numbers);
                                          startActivity(intent);
                                      }
                                  });

        invest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String numbers=phones.getText().toString();

                Intent intent = new Intent(home.this, Investment.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });

        payments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home.this, Send_money.class);
                intent.putExtra("number",numbers);
                startActivity(intent);
            }
        });

    }

    private String convertText(String text){
        StringBuilder stringBuilder = new StringBuilder(text);
        for (int i = stringBuilder.length() - 6;i>0;i-=3){
            stringBuilder.insert(i,",");


        }
        return stringBuilder.toString();
    }


    private void checkUser() {

        DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {

                            String bal = ""+ds.child("Account").getValue();

                            Balance.setText(convertText(bal+".00"));


                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }
}
