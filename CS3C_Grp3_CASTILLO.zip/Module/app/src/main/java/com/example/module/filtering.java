package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class filtering extends AppCompatActivity {
    String numbers;

    AutoCompleteTextView services;
    Button sends,savings, receives;
    LinearLayout lsavings,lsend,lreceived;
    private EditText searchProductEt,months,months1,months2 ;
    RecyclerView savingsRv,sendsRv,recievesRv;
    private FirebaseAuth firebaseAuth;
    private ArrayList<modelHistory> AppointmentsLists;

    private adapterHistorys adapterAppointments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtering);

        Intent intent = getIntent();
        numbers = intent.getStringExtra("number");

        months = findViewById(R.id.months);
        months1 = findViewById(R.id.months1);
        months2 = findViewById(R.id.months2);




        sends= findViewById(R.id.sends);
        savings= findViewById(R.id.savings);
        receives= findViewById(R.id.recieves);


        lreceived= findViewById(R.id.lreceived);
        lsavings= findViewById(R.id.lsavings);
        lsend= findViewById(R.id.lsend);

        savingsRv= findViewById(R.id.savingsRv);
        sendsRv= findViewById(R.id.sendsRv);
        recievesRv= findViewById(R.id.recievesRv);




        sends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    lsend.setVisibility(View.VISIBLE);
                lsavings.setVisibility(View.GONE);
                lreceived.setVisibility(View.GONE);
                loadHistory1();
            }
        });

       receives.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lsend.setVisibility(View.GONE);
                lsavings.setVisibility(View.GONE);
                lreceived.setVisibility(View.VISIBLE);
                loadHistory2();
            }
        });




        savings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lsend.setVisibility(View.GONE);
                lsavings.setVisibility(View.VISIBLE);
                lreceived.setVisibility(View.GONE);
             loadHistory();
            }
        });

















    }



    private void loadHistory() {

        months.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    adapterAppointments.getFilter().filter(s);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String uid = "" + ds.child("Phone").getValue();
                            String trans = "" + ds.child("Transaction").getValue();

                            AppointmentsLists= new ArrayList<>();
                            DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Transaction");
                            ref.orderByChild("Transaction").equalTo("Savings")
                                    .addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            for (DataSnapshot ds : snapshot.getChildren()) {
                                                modelHistory modelAppoint = ds.getValue(modelHistory.class);
                                                AppointmentsLists.add(modelAppoint);

                                            }
                                            //setup adapter
                                            adapterAppointments = new adapterHistorys(filtering.this, AppointmentsLists);
                                            //set adapter
                                            savingsRv.setAdapter(adapterAppointments);
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });


                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void loadHistory1() {

        months1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    adapterAppointments.getFilter().filter(s);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String uid = "" + ds.child("Phone").getValue();
                            String trans = "" + ds.child("Transaction").getValue();

                            AppointmentsLists= new ArrayList<>();
                            DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Transaction");
                            ref.orderByChild("Transaction").equalTo("Send Money")
                                    .addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            for (DataSnapshot ds : snapshot.getChildren()) {
                                                modelHistory modelAppoint = ds.getValue(modelHistory.class);
                                                AppointmentsLists.add(modelAppoint);

                                            }
                                            //setup adapter
                                            adapterAppointments = new adapterHistorys(filtering.this, AppointmentsLists);
                                            //set adapter
                                            sendsRv.setAdapter(adapterAppointments);
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });


                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void loadHistory2() {
        months2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    adapterAppointments.getFilter().filter(s);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });



        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numbers)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String uid = "" + ds.child("Phone").getValue();
                            String trans = "" + ds.child("Transaction").getValue();

                            AppointmentsLists= new ArrayList<>();
                            DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Transaction");
                            ref.orderByChild("Transaction").equalTo("Received Money")
                                    .addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            for (DataSnapshot ds : snapshot.getChildren()) {
                                                modelHistory modelAppoint = ds.getValue(modelHistory.class);
                                                AppointmentsLists.add(modelAppoint);

                                            }
                                            //setup adapter
                                            adapterAppointments = new adapterHistorys(filtering.this, AppointmentsLists);
                                            //set adapter
                                            recievesRv.setAdapter(adapterAppointments);
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });


                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}