package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Deposit extends AppCompatActivity {
    private TextView totalSavingsAmountTextView;
    private RecyclerView recyclerView;

    private FloatingActionButton add;
    private DatabaseReference savingsRef;
    private FirebaseAuth mAuth;
    private ProgressDialog loader;

    public Deposit() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposit);

        mAuth = FirebaseAuth.getInstance();
        savingsRef = FirebaseDatabase.getInstance().getReference().child("Savings").child(mAuth.getCurrentUser().getUid());
        loader = new ProgressDialog(this);

        totalSavingsAmountTextView = findViewById(R.id.totalbalance);
        recyclerView = findViewById(R.id.recyclerview);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);

        add = findViewById(R.id.add);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                additem();
            }
        });
    }

    private void additem() {
        AlertDialog.Builder myDialog = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View myView = inflater.inflate(R.layout.input_layout, null);
        myDialog.setView(myView);

        final AlertDialog dialog = myDialog.create();
        dialog.setCancelable(false);

        final Spinner itemspinner = myView.findViewById(R.id.itemspinner);
        final EditText amount = myView.findViewById(R.id.amount);
        final Button cancel = myView.findViewById(R.id.cancel);
        final Button save = myView.findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String savingsAmount = amount.getText().toString();
                String savingsitem = itemspinner.getSelectedItem().toString();

                if(TextUtils.isEmpty(savingsAmount)){
                    amount.setError("Amount is Required");
                    return;
                }
                if(savingsitem.equals("Select item")){
                    Toast.makeText(Deposit.this, "Select a valid item", Toast.LENGTH_SHORT).show();

                }
                else{
                    loader.setMessage("adding a Savings Item");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();


                    String id = savingsRef.push().getKey();

                    SavingsData savingsData = new SavingsData(savingsitem, id, null, Integer.parseInt(savingsAmount));
                    savingsRef.child(id).setValue(savingsData).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                if (task.isSuccessful()) {
                                    Toast.makeText(Deposit.this, "Savings item added successfully", Toast.LENGTH_SHORT).show();

                                } else {
                                    Toast.makeText(Deposit.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                                }
                                loader.dismiss();
                            }
                        }
                    });
                }
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();

    }
}
