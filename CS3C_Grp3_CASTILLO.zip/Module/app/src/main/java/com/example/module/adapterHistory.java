package com.example.module;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapterHistory extends RecyclerView.Adapter<adapterHistory.HolderAppointment>implements Filterable {
    private Context context;
    public ArrayList<modelHistory> appointmentList,filterList;
    private filtertrans filter;



    public adapterHistory(Context context, ArrayList<modelHistory> appointmentList) {
        this.context = context;
        this.appointmentList = appointmentList;
        this.filterList = appointmentList;
    }




    @NonNull
    @Override
    public adapterHistory.HolderAppointment onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_history,parent,false);
        return new adapterHistory.HolderAppointment(view);
    }

    @Override
    public void onBindViewHolder(@NonNull adapterHistory.HolderAppointment holder, int position) {
        modelHistory modelHistory = appointmentList.get(position);
        String transaction1 = modelHistory .getTransaction();
        String date1 = modelHistory .getDate();
        String time1 = modelHistory .getTime();
        String send1 = modelHistory .getSend();
        String from1 = modelHistory .getFrom();
        String amount1 = modelHistory .getAmount();
        String Uids  =modelHistory .getUid();
        String timestamps  =modelHistory .getTimestamp();


        //set data

        holder.sendx.setText(send1);
        holder.amountx.setText(amount1);
        holder.fromx.setText(from1);
        holder.datex.setText(date1);
        holder.timex.setText(time1);
        holder.transx.setText(transaction1);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    @Override
    public Filter getFilter() {
        if (filter==null){
            filter = new filtertrans(this,filterList);
        }
        return filter;
    }

    @Override
    public int getItemCount() {
        return appointmentList.size(); //return number of records
    }



    public class HolderAppointment extends RecyclerView.ViewHolder {



        private TextView sendx, fromx, amountx ,transx ,datex,timex;

        public HolderAppointment(@NonNull View itemView) {
            super(itemView);

            sendx = itemView.findViewById(R.id.sends1);
            fromx= itemView.findViewById(R.id.froms1);
            amountx = itemView.findViewById(R.id.amounts1);
            transx = itemView.findViewById(R.id.names1);
            datex = itemView.findViewById(R.id.dates1);
            timex = itemView.findViewById(R.id.times1);






        }

    }
}
