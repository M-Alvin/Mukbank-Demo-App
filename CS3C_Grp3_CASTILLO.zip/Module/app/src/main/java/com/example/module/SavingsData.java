package com.example.module;

public class SavingsData {
    String item,notes,id;
    int amount;

    public SavingsData() {
    }

    public SavingsData(String item, String notes, String id, int amount) {
        this.item = item;
        this.notes = notes;
        this.id = id;
        this.amount = amount;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}

