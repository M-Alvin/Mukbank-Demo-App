package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Send_money extends AppCompatActivity {

    ImageView backs;
    EditText amount,number;
    String numberss, bal , bal1;
    int bals,bals1;
    TextView send1,receive1;
    Button sends;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_money);

        Intent intent = getIntent();
        numberss = intent.getStringExtra("number");

        amount = findViewById(R.id.amounts);
        number=findViewById(R.id.numbers);
        sends=findViewById(R.id.send);
        send1=findViewById(R.id.sends);
        receive1=findViewById(R.id.recieves);
        backs=findViewById(R.id.back);


        backs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Send_money.this, home.class);
                intent.putExtra("number",numberss);
                startActivity(intent);
            }
        });

        DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numberss)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {

                            bal = ""+ds.child("Account").getValue();

                        }





                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });



        sends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                send();

            }
        });





    }

    int amount2;
    String number1, amount1,tot , tot1;
    private void send() {
        amount1 = amount.getText().toString().trim();
        number1 = number.getText().toString().trim();

        DatabaseReference ref =  FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+number1)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding
                        for (DataSnapshot ds : snapshot.getChildren()) {

                            bal1 = "" + ds.child("Account").getValue();


                        }
                        compute();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


    }

    private void compute() {




        send1.setText(bal);
        receive1.setText(bal1);

        String send= send1.getText().toString();
        String receive= receive1.getText().toString();


        Intent intent = new Intent(Send_money.this, Confirm_money.class);
        intent.putExtra("number",numberss);
        intent.putExtra("amount",amount1);
        intent.putExtra("number1",number1);
        intent.putExtra("send",send);
        intent.putExtra("receive",receive);
        startActivity(intent);


    }


    private void addData() {
        String wew1 = send1.getText().toString();
        String wew2 = receive1.getText().toString();



        HashMap<String, Object> hashMap1 = new HashMap<>();
        hashMap1.put("Account", "" + wew1);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(""+numberss).updateChildren(hashMap1)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        HashMap<String, Object> hashMap2 = new HashMap<>();
                        hashMap2.put("Account", "" + wew2);

                        DatabaseReference references = FirebaseDatabase.getInstance().getReference("Users");
                        references.child(""+number1).updateChildren(hashMap2)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {

                                        Toast.makeText(Send_money.this, "Done", Toast.LENGTH_SHORT).show();

                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(Send_money.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Send_money.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


    }

    private void gotos() {


    }


}