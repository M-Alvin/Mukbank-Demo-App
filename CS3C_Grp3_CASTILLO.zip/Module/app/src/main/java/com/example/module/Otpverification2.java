package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class Otpverification2 extends AppCompatActivity {
    private EditText inputCode1, inputCode2, inputCode3, inputCode4, inputCode5, inputCode6;
    private String verificationId;
    private FirebaseAuth firebaseAuth;
    String username,email,password,phone,conpass,mobs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification2);

        Intent intent =getIntent();

          username = intent.getStringExtra("usernames");
        email = intent.getStringExtra("emails");
        password = intent.getStringExtra("passwords");
         phone = "0" + intent.getStringExtra("mobs");
         conpass = intent.getStringExtra("conpasss");
        mobs = intent.getStringExtra("mobile");


        firebaseAuth = FirebaseAuth.getInstance();



        TextView textMobile = findViewById(R.id.txtDisplayMobile);
        textMobile.setText(String.format("+63%s",getIntent().getStringExtra("mobile")
        ));


        inputCode1 = findViewById(R.id.etCode1);
        inputCode2 = findViewById(R.id.etCode2);
        inputCode3 = findViewById(R.id.etCode3);
        inputCode4 = findViewById(R.id.etCode4);
        inputCode5 = findViewById(R.id.etCode5);
        inputCode6 = findViewById(R.id.etCode6);

        setupOTPInputs();
        final Button buttonVerify = findViewById(R.id.verifyotpnum);

        verificationId = getIntent().getStringExtra("verificationId");
        buttonVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(inputCode1.getText().toString().trim().isEmpty()
                        || inputCode2.getText().toString().trim().isEmpty()
                        || inputCode3.getText().toString().trim().isEmpty()
                        || inputCode4.getText().toString().trim().isEmpty()
                        || inputCode5.getText().toString().trim().isEmpty()
                        || inputCode6.getText().toString().trim().isEmpty()){
                    Toast.makeText(Otpverification2.this, "Enter a valid code",Toast.LENGTH_SHORT).show();
                    return;
                }
                String code =
                        inputCode1.getText().toString() +
                                inputCode2.getText().toString() +
                                inputCode3.getText().toString() +
                                inputCode4.getText().toString() +
                                inputCode5.getText().toString() +
                                inputCode6.getText().toString();

                if(verificationId != null){
                    buttonVerify.setVisibility(View.INVISIBLE);
                    PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(
                            verificationId,
                            code
                    );
                    FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    buttonVerify.setVisibility(View.VISIBLE);
                                    if(task.isSuccessful()){
                                        inputData();
                                    }else{
                                        Toast.makeText(Otpverification2.this, "Verification code invalid", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }


            }

        });

        findViewById(R.id.resendotp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        "+63" + getIntent().getStringExtra("mobile"), //country code + mobile number
                        60, //timeout in seconds
                        TimeUnit.SECONDS, //cant get new code until the timeout is finished
                        Otpverification2.this,

                        new com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks() {


                            //if verification is sent
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                            }

                            //if verification is failed or no signal/internet
                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Toast.makeText(Otpverification2.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                            //if verification is sent  and ready to verify
                            @Override
                            public void onCodeSent(@NonNull String newVerificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                verificationId = newVerificationId;
                                Toast.makeText(Otpverification2.this, "OTP Sent", Toast.LENGTH_SHORT).show();
                            }

                        }

                );
            }
        });

    }

    private String username1,phone1,email1,password1,conpass1;
    private void inputData() {



        username1 = username.toString().trim();
        email1 = email.toString().trim();
        password1 = password.toString().trim();
        phone1 = phone.toString().trim();
        conpass1 = conpass.toString().trim();

        createAccount();

    }

    private void createAccount() {

        //create account
        firebaseAuth.createUserWithEmailAndPassword(email1,password1)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {


                        saverFirebase();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Otpverification2.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void saverFirebase() {


        final String timestamp = ""+System.currentTimeMillis();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("uid", "" + firebaseAuth.getUid());
        hashMap.put("Username", "" + username1);
        hashMap.put("Password", "" + password1);
        hashMap.put("Account", "" + "0");
        hashMap.put("Savings", "" + "0");
        hashMap.put("Phone", "" + phone1);
        hashMap.put("Email", "" + email1);
        hashMap.put("timestamp", "" + timestamp);

        // add db
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child("0"+mobs).setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(Otpverification2.this, "Registration Finished", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Otpverification2.this, SignIn.class));
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Otpverification2.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });





    }
    private void setupOTPInputs(){
        inputCode1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                if(!charSequence.toString().trim().isEmpty()) {
                    inputCode2.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        inputCode2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                if(!charSequence.toString().trim().isEmpty()) {
                    inputCode3.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        inputCode3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                if(!charSequence.toString().trim().isEmpty()) {
                    inputCode4.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        inputCode4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                if(!charSequence.toString().trim().isEmpty()) {
                    inputCode5.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        inputCode5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                if(!charSequence.toString().trim().isEmpty()) {
                    inputCode6.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
}