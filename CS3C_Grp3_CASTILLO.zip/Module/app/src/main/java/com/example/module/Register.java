package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {
    private Button createacc;
    EditText pass, un, e_mail, conpass;
    DatabaseReference module;
    CheckBox check;
    FirebaseAuth mAuth;
    FirebaseUser mUser;
    TextView login_now,term;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        login_now = (TextView) findViewById(R.id.loginnow);
        String text= "Already have an account? LOGIN.";
        SpannableString ss = new SpannableString(text);

        ClickableSpan clickableSpan1 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {
                openmainLogin();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.WHITE);
                ds.setUnderlineText(false);
                ds.setTypeface(Typeface.DEFAULT_BOLD);
            }
        };

        ss.setSpan(clickableSpan1, 20, 30, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        login_now.setText(ss);
        login_now.setMovementMethod(LinkMovementMethod.getInstance());


        e_mail = (EditText) findViewById(R.id.email);
        un = (EditText) findViewById(R.id.username);
        pass = (EditText) findViewById(R.id.password);
        conpass = (EditText) findViewById(R.id.confirmpassword);

        check = findViewById(R.id.checks);
        term = findViewById(R.id.terms);


        term.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent (Register.this,termsCondition.class);
                startActivity(intent);
            }
        });

        createacc =(Button)  findViewById(R.id.createacc);
        createacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email=e_mail.getText().toString();
                String username=un.getText().toString();
                String password=pass.getText().toString();
                String confirmpass=conpass.getText().toString();

                if (email.isEmpty()) {
                    e_mail.setError("Email is required");
                    e_mail.requestFocus();
                    return;
                }

                if (username.isEmpty()) {
                    un.setError("Username is required");
                    un.requestFocus();
                    return;
                }

                if (password.isEmpty()) {
                    pass.setError("Password is required");
                    pass.requestFocus();
                    return;
                }

                if (password.length()<6) {
                    pass.setError("Password needs to have 6 characters.");
                    pass.requestFocus();
                    return;
                }

                if (confirmpass.isEmpty()) {
                    conpass.setError("Confirm Password is required");
                    conpass.requestFocus();
                    return;
                }

                if (!confirmpass.equals(password)) {
                    conpass.setError("Password not Matched");
                    conpass.requestFocus();
                    return;
                }

                else {

                    if (check.isChecked()){

                    Intent intent =new Intent (getApplicationContext(),otpcode.class);

                    intent.putExtra("username",username);
                    intent.putExtra("email",email);
                    intent.putExtra("password",password);
                    intent.putExtra("conpass",confirmpass);

                    startActivity(intent);

                    }
                    else{
                        Toast.makeText(Register.this, "Please read and check the Terms and Condition ", Toast.LENGTH_SHORT).show();
                    }


                }
            }

        });
    }
   

    public void openmainLogin(){
        Intent intent = new Intent(this, SignIn.class);
        startActivity(intent);
    }
}
