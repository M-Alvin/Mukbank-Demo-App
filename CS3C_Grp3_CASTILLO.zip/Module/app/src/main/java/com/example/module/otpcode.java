package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hbb20.CountryCodePicker;

import java.util.concurrent.TimeUnit;

public class otpcode extends AppCompatActivity {


    DatabaseReference databaseReference = FirebaseDatabase.getInstance ().getReferenceFromUrl ("https://module-c8b9a-default-rtdb.firebaseio.com/");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpcode);


        final Button getotp;
        final EditText inputMobile;


        inputMobile=(EditText) findViewById(R.id.entermobile);
        getotp = (Button)  findViewById(R.id.getotpnum);


        Intent intent =getIntent();

        String usernames = intent.getStringExtra("username");
        String emails = intent.getStringExtra("email");
        String passwords = intent.getStringExtra("password");
        String conpasswords= intent.getStringExtra("conpass");

       getotp.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               if(inputMobile.getText().toString().trim().isEmpty()){
                   Toast.makeText(otpcode.this,"Enter mobile ",Toast.LENGTH_SHORT).show();
                   return;
               }
               getotp.setVisibility(View.INVISIBLE);


               getotp.setVisibility(View.INVISIBLE);

               PhoneAuthProvider.getInstance().verifyPhoneNumber(
                       "+63" + inputMobile.getText().toString(),
                       60,
                       TimeUnit.SECONDS,
                       otpcode.this,
                       new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                           @Override
                           public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                               getotp.setVisibility(View.VISIBLE);

                           }

                           @Override
                           public void onVerificationFailed(@NonNull FirebaseException e) {

                               getotp.setVisibility(View.VISIBLE);
                               Toast.makeText(otpcode.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                           }

                           @Override
                           public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {

                               getotp.setVisibility(View.VISIBLE);


                               String username = usernames.toString();
                               String password = passwords.toString();
                               String phones = inputMobile.getText().toString();
                               String email = emails.toString();
                               String conpass = conpasswords.toString();


                               Intent intent = new Intent(getApplicationContext(), Otpverification2.class);

                               intent.putExtra("usernames", username);
                               intent.putExtra("emails", email);
                               intent.putExtra("passwords", password);
                               intent.putExtra("conpasss", conpass);
                               intent.putExtra("mobs", phones);


                               intent.putExtra("mobile", phones);
                               intent.putExtra("verificationId", verificationId);
                               startActivity(intent);


                           }
                       }

               );

           }
       });

    }

}
