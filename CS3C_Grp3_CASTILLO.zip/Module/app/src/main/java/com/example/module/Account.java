package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Account extends AppCompatActivity {
    String numberss, fullnames, emails ,phones , passwords ;
    ImageView backs, edits,archives;
    TextView name,number,email;
    private Button btnlogout;
    Button saves1,cancels1;

    EditText names1,numbers1,emails1;
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        btnlogout = (Button) findViewById(R.id.btnLogout);


        Intent intent = getIntent();
        numberss= intent.getStringExtra("number");

        backs = findViewById(R.id.back);
        name = findViewById(R.id.names);
        number = findViewById(R.id.numbers);
        email = findViewById(R.id.emails);
        edits = findViewById(R.id.edit);
        archives = findViewById(R.id.archive);

        loadmyinfo();


        edits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Account.this, confirmChange.class);
                intent.putExtra("name",fullnames);
                intent.putExtra("email",emails);
                intent.putExtra("phone",phones);
                intent.putExtra("number",numberss);
                intent.putExtra("password",passwords);
                startActivity(intent);
            }
        });

        archives.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Account.this, archive.class);
                intent.putExtra("numbers",numberss);
                startActivity(intent);

            }
        });

        backs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Account.this, home.class);
                intent.putExtra("number",numberss);
                startActivity(intent);
            }
        });
        btnlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Account.this, SignIn.class);
                startActivity(intent);
            }
        });
    }


    String email2,name2,number2;
    private void saved() {

        email2 =emails1.getText().toString().trim();
        name2= names1.getText().toString().trim();
        number2= numbers1.getText().toString().trim();

        HashMap<String, Object> hashMap1 = new HashMap<>();
        hashMap1.put("Email", "" + email2);
        hashMap1.put("Username", "" + name2);
        hashMap1.put("Phone", "" + number2);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(""+numberss).updateChildren(hashMap1)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Account.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }






    private void loadmyinfo() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+numberss)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot ds: snapshot.getChildren()){
                             fullnames = ""+ds.child("Username").getValue();
                            emails= ""+ds.child("Email").getValue();
                            phones = ""+ds.child("Phone").getValue();
                            passwords = ""+ds.child("Password").getValue();



                        }
                        name.setText(fullnames);
                        email.setText(emails);

                        number.setText(phones);


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}