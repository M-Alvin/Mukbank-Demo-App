package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class confirmChange extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    String emailx,namex, numberx , phonex,passx;
    EditText emails, names, numbers ,passs;
    Button saves, cancels;
    TextView num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_change);


        emails = findViewById(R.id.email1);
        names = findViewById(R.id.name1);
        numbers = findViewById(R.id.number1);
        passs = findViewById(R.id.pass1);
        saves = findViewById(R.id.save);
        cancels = findViewById(R.id.cancels);
        num = findViewById(R.id.nums);
        firebaseAuth = FirebaseAuth.getInstance();


        Intent intent = getIntent();

        numberx =intent.getStringExtra("number");
        phonex= intent.getStringExtra("phone");
        emailx= intent.getStringExtra("email");
        namex= intent.getStringExtra("name");
        passx= intent.getStringExtra("password");


        emails.setText(emailx);
        names.setText(namex);
        numbers.setText(phonex);
        passs.setText(passx);


        saves.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
            }
        });

        cancels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(confirmChange.this, home.class);
                intent.putExtra("number",numberx);
                startActivity(intent);
            }
        });



    }



    String email2,name2,number2,pass2;
    private void save() {

        email2 =emails.getText().toString().trim();
        name2= names.getText().toString().trim();
        number2= numbers.getText().toString().trim();
        pass2= passs.getText().toString().trim();


                        //starttttttttttttttttttttttttttttttt --------------------
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("Phone", "" + number2);
        hashMap.put("Email", "" + email2);
        hashMap.put("Username", "" + name2);
        hashMap.put("Password", "" + pass2);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(""+numberx).updateChildren(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        wew();

                        Toast.makeText(confirmChange.this, "Update Finished", Toast.LENGTH_SHORT).show();

                                        Intent intent = new Intent(confirmChange.this, home.class);
                                        intent.putExtra("number",number2);
                                        startActivity(intent);


                }


                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(confirmChange.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        ///enddddddd ----------

}

    private void wew() {
        firebaseAuth.createUserWithEmailAndPassword(email2,pass2)
        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {



                    }
                     })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(confirmChange.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });

}
}