package com.example.module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.hotspot2.pps.HomeSp;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;

public class Confirm_money extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;

    String amountc , numberc, number1c ,sendc,receivec ,tots,tots1;
    Button done1 ,cancels;
    TextView amount,send,recieve,number1,number ,en,ev;
    String amounti,sendi,receivei,numberi,numberii , timestamp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_money);

        amount = findViewById(R.id.amounts);
        send = findViewById(R.id.sends);
        recieve = findViewById(R.id.recieves);
        number = findViewById(R.id.numbers);
        number1 = findViewById(R.id.numbers1);
        en = findViewById(R.id.se);
         ev= findViewById(R.id.re);
        done1= findViewById(R.id.send1);
        cancels= findViewById(R.id.cancel1);
        firebaseAuth = FirebaseAuth.getInstance();


        Intent intent = getIntent();
        numberi = intent.getStringExtra("number");
        amounti = intent.getStringExtra("amount");
        numberii = intent.getStringExtra("number1");
        sendi = intent.getStringExtra("send");
        receivei = intent.getStringExtra("receive");

        number.setText(numberi);
        amount.setText(amounti);
        number1.setText(numberii);
        send.setText(sendi);
        recieve.setText(receivei);




        amountc = amount.getText().toString().trim();
        numberc = number.getText().toString().trim();
        number1c = number1.getText().toString().trim();
        sendc = send.getText().toString().trim();
        receivec = recieve.getText().toString().trim();


        int amount2 = Integer.parseInt(amountc);
        int tot = Integer.parseInt(sendc);
        int tot1 = Integer.parseInt(receivec);


        int total = tot-amount2;

        int total1 = tot1 + amount2;

        tots1 = String.valueOf(total1);

        tots = String.valueOf(total);

        en.setText(tots);
        ev.setText(tots1);

        done1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(Confirm_money.this);
                builder.setTitle("Confirmation")
                        .setMessage("Are you sure you want to transfer your money??")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {



                                if (tot>=amount2 || tot == amount2){
                                    next();
                                }
                                else  {
                                    Toast.makeText(Confirm_money.this, "insufficient balance",Toast.LENGTH_SHORT).show();
                                }

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).show();


            }

        });




        cancels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Confirm_money.this, home.class);
                intent.putExtra("number",numberc);
                startActivity(intent);
            }
        });




    }


    private void next() {
        HashMap<String, Object> hashMap1 = new HashMap<>();
        hashMap1.put("Account", "" + tots);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(""+numberc).updateChildren(hashMap1)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                                        HashMap<String, Object> hashMap2 = new HashMap<>();
                                        hashMap2.put("Account", "" + tots1);

                                        timestamp = "" + System.currentTimeMillis();
                                        DatabaseReference references = FirebaseDatabase.getInstance().getReference("Users");
                                        references.child(""+number1c).updateChildren(hashMap2)
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {

                                                        Intent intent = new Intent(Confirm_money.this, receipt.class);
                                                        intent.putExtra("from",numberc);
                                                        intent.putExtra("send",number1c);
                                                        intent.putExtra("phone",numberc);
                                                        intent.putExtra("amount",amountc);
                                                        intent.putExtra("number",numberc);
                                                        intent.putExtra("timestamp",timestamp);
                                                        startActivity(intent);



                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        Toast.makeText(Confirm_money.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                                    }
                                                });


                    }

                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Confirm_money.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }







}