package com.example.module;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class adapterArchive  extends RecyclerView.Adapter<adapterArchive.HolderApoinment> {


    private Context context;
    public ArrayList<modelArchive> appointmentList;

    public adapterArchive(Context context, ArrayList<modelArchive> appointmentList) {
        this.context = context;
        this.appointmentList = appointmentList;
    }



    @NonNull
    @Override
    public adapterArchive.HolderApoinment onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_archive,parent,false);
        return new adapterArchive.HolderApoinment(view);
    }

    @Override
    public void onBindViewHolder(@NonNull adapterArchive.HolderApoinment holder, int position) {
        modelArchive modelArchive = appointmentList.get(position);
        String saving1 = modelArchive .getSavings();
        String amount1 = modelArchive .getAmount();
        String balance1 = modelArchive .getBalance();
        String phone1 = modelArchive .getPhone();
        String Uids  =modelArchive .getUid();
        String timestamps  =modelArchive .getTimestamp();


        //set data

        holder.saving.setText(saving1);
        holder.amount.setText(amount1);
        holder.balance.setText(balance1);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                details(modelArchive); //contrains details of click appointment

            }
        });
    }
    private BottomSheetDialog bottomSheetDialog;
    private void details(modelArchive modelArchive) {
        bottomSheetDialog = new BottomSheetDialog(context);
        View view  = LayoutInflater.from(context).inflate(R.layout.archive_view,null);
        bottomSheetDialog.setContentView(view);


        TextView itemx = view.findViewById(R.id.items);
        TextView amountx = view.findViewById(R.id.amounts);
        TextView balancex = view.findViewById(R.id.balances);
        Button deletex = view.findViewById(R.id.deletes);
        Button restorex = view.findViewById(R.id.restores);

        String saving1 = modelArchive .getSavings();
        String amount1 = modelArchive .getAmount();
        String balance1 = modelArchive .getBalance();
        String phone1 = modelArchive .getPhone();
        String Uids  =modelArchive .getUid();
        String timestamps  =modelArchive .getTimestamp();

        itemx.setText(saving1);
        amountx.setText(amount1);
        balancex.setText(balance1);


        //show dialog
        bottomSheetDialog.show();


        deletex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Cancel")
                        .setMessage("Are you sure you want to delete this transaction?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                delete(modelArchive);

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).show();
            }
        });

        restorex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Cancel")
                        .setMessage("Are you sure you want to restore this transaction?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                restore(modelArchive);

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).show();
            }
        });



    }



    private void restore(modelArchive modelArchive) {

        String saving1 = modelArchive .getSavings();
        String amount1 = modelArchive .getAmount();
        String balance1 = modelArchive .getBalance();
        String phone1 = modelArchive .getPhone();
        String Uids  =modelArchive .getUid();
        String timestamps  =modelArchive .getTimestamp();


        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("Savings", "" + saving1);
        hashMap.put("Amount", "" + amount1);
        hashMap.put("Balance", "" + balance1);
        hashMap.put("Phone", "" + phone1);
        hashMap.put("timestamp", "" + timestamps);
        hashMap.put("uid", "" + Uids);

        //add now to database
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        reference.child(""+phone1).child("Savings").child(timestamps).setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {

                    @Override
                    public void onSuccess(Void aVoid) {

                        Toast.makeText(context, "Data Restored", Toast.LENGTH_SHORT).show();

                        restores(timestamps,phone1);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }

    private void restores(String timestamps, String phone1) {

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+phone1)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String phones = "" + ds.child("Phone").getValue();

                            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
                            reference.child(phones).child("Archive").child(timestamps).removeValue()
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            bottomSheetDialog.dismiss();

                                            ///starttt --------


                                            ///end ----
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            bottomSheetDialog.dismiss();
                                            Toast.makeText(context,""+e.getMessage(),Toast.LENGTH_SHORT).show();
                                        }
                                    });



                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }




    private void delete(modelArchive modelArchive) {

        String saving1 = modelArchive .getSavings();
        String amount1 = modelArchive .getAmount();
        String balance1 = modelArchive .getBalance();
        String phone1 = modelArchive .getPhone();
        String Uids  =modelArchive .getUid();
        String timestamps  =modelArchive .getTimestamp();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("Phone").equalTo(""+phone1)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //clear list  before adding

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String phones = "" + ds.child("Phone").getValue();

                            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
                            reference.child(phones).child("Archive").child(timestamps).removeValue()
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            bottomSheetDialog.dismiss();

                                            ///starttt --------


                                            ///end ----
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            bottomSheetDialog.dismiss();
                                            Toast.makeText(context,""+e.getMessage(),Toast.LENGTH_SHORT).show();
                                        }
                                    });



                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    @Override
    public int getItemCount() {
        return appointmentList.size(); //return number of records
    }


    public class HolderApoinment extends RecyclerView.ViewHolder {



        private TextView saving, amount, balance ;

        public HolderApoinment(@NonNull View itemView) {
            super(itemView);

            saving = itemView.findViewById(R.id.savings);
            balance= itemView.findViewById(R.id.balances);
            amount = itemView.findViewById(R.id.amounts);





        }

    }

}
