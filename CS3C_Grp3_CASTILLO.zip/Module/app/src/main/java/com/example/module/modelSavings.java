package com.example.module;

public class modelSavings {
    private String Savings, Balance , Amount, timestamp ,uid, Phone ;

    public modelSavings() {

    }


    public modelSavings(String savings, String balance, String amount, String timestamp, String uid, String phone) {
        Savings = savings;
        Balance = balance;
        Amount = amount;
        this.timestamp = timestamp;
        this.uid = uid;
        Phone = phone;
    }

    public String getSavings() {
        return Savings;
    }

    public void setSavings(String savings) {
        Savings = savings;
    }

    public String getBalance() {
        return Balance;
    }

    public void setBalance(String balance) {
        Balance = balance;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }
}
